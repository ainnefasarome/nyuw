package com.nyuw.hans;

import android.content.Context;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public class Store {
    private final SharedPreferences sp;

    public Store(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("nyuw", Context.MODE_PRIVATE);
    }

    public int days() { return sp.getInt("days", 2); }
    public void setDays(int d) { sp.edit().putInt("days", Math.max(1, Math.min(30, d))).apply(); }

    public boolean auto() { return sp.getBoolean("auto", true); }
    public void setAuto(boolean b) { sp.edit().putBoolean("auto", b).apply(); }

    public long lastRun() { return sp.getLong("last", 0L); }
    public void setLastRun(long t) { sp.edit().putLong("last", t).apply(); }

    public Set<String> get(String k) {
        return new HashSet<String>(sp.getStringSet(k, new HashSet<String>()));
    }

    public void put(String k, Set<String> v) {
        sp.edit().putStringSet(k, new HashSet<String>(v)).apply();
    }

    public String log() { return sp.getString("log", ""); }
    public void clearLog() { sp.edit().remove("log").apply(); }

    public synchronized void addLog(String s) {
        String t = new SimpleDateFormat("dd/MM HH:mm", Locale.US).format(new Date());
        String all = t + "  " + s + "\n" + sp.getString("log", "");
        String[] ls = all.split("\n");
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < ls.length && i < 60; i++) b.append(ls[i]).append("\n");
        sp.edit().putString("log", b.toString()).apply();
    }
}
