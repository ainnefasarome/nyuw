package com.nyuw.hans;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {

    private static final int WHITE = 0xFFFFFFFF;
    private static final int GRAY = 0xFFB0BAC5;
    private static final int GREEN = 0xFF2EE6A6;
    private static final int RED = 0xFFFF6B6B;

    private Store st;
    private List<String> scan = null;
    private final Map<String, Boolean> chk = new HashMap<String, Boolean>();
    private final Map<String, Boolean> chkOff = new HashMap<String, Boolean>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        st = new Store(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView tv(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setPadding(0, dp(8), 0, dp(2));
        return t;
    }

    private Button btn(String s, View.OnClickListener l) {
        Button x = new Button(this);
        x.setText(s);
        x.setAllCaps(false);
        x.setOnClickListener(l);
        return x;
    }

    private CheckBox cb(String s, boolean on, CompoundButton.OnCheckedChangeListener l) {
        CheckBox c = new CheckBox(this);
        c.setText(s);
        c.setTextColor(WHITE);
        c.setChecked(on);
        c.setOnCheckedChangeListener(l);
        return c;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private void run(List<String> l, boolean restore) {
        NyuwService s = NyuwService.inst;
        if (s == null) { toast("Aktifkan Aksesibilitas nyuw dulu"); return; }
        if (l.isEmpty()) { toast("Belum ada yang dicentang"); return; }
        if (!s.startRun(l, restore)) { toast("nyuw masih bekerja, tunggu selesai"); return; }
        if (!restore) scan = null;
    }

    private void render() {
        final boolean usage = Apps.hasUsage(this);
        final boolean acc = NyuwService.inst != null;

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF0B0F14);
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(dp(16), dp(20), dp(16), dp(40));
        sv.addView(r);

        r.addView(tv("nyuw", 30, GREEN, true));
        r.addView(tv("Matikan internet aplikasi yang jarang dipakai", 14, GRAY, false));

        // --- izin
        r.addView(tv("1. Akses Penggunaan: " + (usage ? "AKTIF" : "BELUM"), 16,
                usage ? GREEN : RED, true));
        if (!usage) {
            r.addView(btn("Aktifkan Akses Penggunaan", new View.OnClickListener() {
                public void onClick(View v) {
                    startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
                }
            }));
        }
        r.addView(tv("2. Aksesibilitas: " + (acc ? "AKTIF" : "BELUM"), 16,
                acc ? GREEN : RED, true));
        if (!acc) {
            r.addView(btn("Aktifkan Aksesibilitas nyuw", new View.OnClickListener() {
                public void onClick(View v) {
                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                }
            }));
            if (Build.VERSION.SDK_INT >= 33) {
                r.addView(tv("Android 13+: jika pilihan nyuw abu-abu, buka Info Aplikasi nyuw, "
                        + "tekan titik tiga di kanan atas, pilih \"Izinkan setelan terbatas\", "
                        + "lalu ulangi.", 12, GRAY, false));
                r.addView(btn("Buka Info Aplikasi nyuw", new View.OnClickListener() {
                    public void onClick(View v) {
                        startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:" + getPackageName())));
                    }
                }));
            }
        }

        // --- pengaturan
        r.addView(tv("Batas tidak dipakai", 14, GRAY, false));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(btn("-", new View.OnClickListener() {
            public void onClick(View v) { st.setDays(st.days() - 1); render(); }
        }));
        row.addView(tv("  " + st.days() + " hari  ", 18, WHITE, true));
        row.addView(btn("+", new View.OnClickListener() {
            public void onClick(View v) { st.setDays(st.days() + 1); render(); }
        }));
        r.addView(row);

        r.addView(cb("Otomatis saat HP dibuka (maks 5 aplikasi sekali jalan)", st.auto(),
                new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton c, boolean on) { st.setAuto(on); }
                }));

        // --- scan
        r.addView(btn("Scan aplikasi jarang dipakai", new View.OnClickListener() {
            public void onClick(View v) {
                if (!Apps.hasUsage(MainActivity.this)) { toast("Aktifkan Akses Penggunaan dulu"); return; }
                scan = Apps.inactive(MainActivity.this, st.days(), st.get("keep"), st.get("off"));
                chk.clear();
                for (String p : scan) chk.put(p, true);
                render();
            }
        }));

        if (scan != null) {
            r.addView(tv("Ditemukan " + scan.size() + " aplikasi tidak dibuka " + st.days()
                    + " hari atau lebih", 15, WHITE, true));
            for (final String p : scan) {
                r.addView(cb(Apps.label(this, p), Boolean.TRUE.equals(chk.get(p)),
                        new CompoundButton.OnCheckedChangeListener() {
                            public void onCheckedChanged(CompoundButton c, boolean on) { chk.put(p, on); }
                        }));
            }
            if (!scan.isEmpty()) {
                r.addView(btn("Matikan internet yang dicentang", new View.OnClickListener() {
                    public void onClick(View v) {
                        List<String> l = new ArrayList<String>();
                        for (String p : scan) if (Boolean.TRUE.equals(chk.get(p))) l.add(p);
                        run(l, false);
                    }
                }));
                r.addView(btn("Kecualikan yang TIDAK dicentang (permanen)", new View.OnClickListener() {
                    public void onClick(View v) {
                        Set<String> keep = st.get("keep");
                        List<String> rest = new ArrayList<String>();
                        for (String p : scan) {
                            if (Boolean.TRUE.equals(chk.get(p))) rest.add(p); else keep.add(p);
                        }
                        st.put("keep", keep);
                        scan = rest;
                        render();
                    }
                }));
            }
        }

        // --- yang sudah dimatikan
        final Set<String> off = st.get("off");
        r.addView(tv("Internet dimatikan oleh nyuw: " + off.size(), 15, WHITE, true));
        final List<String> offList = new ArrayList<String>(off);
        for (final String p : offList) {
            r.addView(cb(Apps.label(this, p), Boolean.TRUE.equals(chkOff.get(p)),
                    new CompoundButton.OnCheckedChangeListener() {
                        public void onCheckedChanged(CompoundButton c, boolean on) { chkOff.put(p, on); }
                    }));
        }
        if (!offList.isEmpty()) {
            r.addView(btn("Pulihkan yang dicentang", new View.OnClickListener() {
                public void onClick(View v) {
                    List<String> l = new ArrayList<String>();
                    for (String p : offList) if (Boolean.TRUE.equals(chkOff.get(p))) l.add(p);
                    run(l, true);
                }
            }));
            r.addView(btn("Lupakan daftar ini (tanpa memulihkan)", new View.OnClickListener() {
                public void onClick(View v) { st.put("off", new HashSet<String>()); render(); }
            }));
        }

        // --- pengecualian
        Set<String> keep = st.get("keep");
        if (!keep.isEmpty()) {
            r.addView(tv("Dikecualikan: " + keep.size() + " aplikasi", 15, WHITE, true));
            r.addView(btn("Kosongkan daftar pengecualian", new View.OnClickListener() {
                public void onClick(View v) { st.put("keep", new HashSet<String>()); render(); }
            }));
        }

        // --- log
        r.addView(tv("Log", 15, WHITE, true));
        String lg = st.log();
        r.addView(tv(lg.length() == 0 ? "(kosong)" : lg, 12, GRAY, false));
        r.addView(btn("Hapus log", new View.OnClickListener() {
            public void onClick(View v) { st.clearLog(); render(); }
        }));

        setContentView(sv);
    }
}
