package com.nyuw.hans;

import android.accessibilityservice.AccessibilityService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Otomatisasi halaman Info Aplikasi: cari menu data, lalu atur
 * (0) data latar belakang, (1) data seluler, (2) Wi-Fi.
 * Teks dicocokkan lintas bahasa/merek (Indonesia + Inggris).
 */
public class NyuwService extends AccessibilityService {

    public static volatile NyuwService inst;

    // kata kunci menu yang membuka halaman data
    private static final String[] ENTRY = {
        "penggunaan data", "pemakaian data", "data usage",
        "mobile data & wi-fi", "mobile data and wi-fi",
        "data seluler & wi-fi", "data seluler dan wi-fi", "data & wi-fi"
    };

    // 0 = data latar belakang, 1 = data seluler, 2 = wi-fi
    private static final String[][] KEYS = {
        { "gunakan data di latar belakang", "data di latar belakang", "data latar belakang",
          "penggunaan data latar belakang", "background data", "background network" },
        { "matikan data seluler", "nonaktifkan data seluler", "matikan data mobile",
          "batasi data seluler", "disable mobile data", "turn off mobile data",
          "disable cellular data", "turn off cellular data", "restrict mobile data",
          "block mobile data" },
        { "nonaktifkan wi-fi", "nonaktifkan wifi", "matikan wi-fi", "matikan wifi",
          "batasi wi-fi", "disable wi-fi", "disable wifi", "turn off wi-fi",
          "turn off wifi", "restrict wi-fi" }
    };

    // kondisi switch saat internet DIMATIKAN
    private static final boolean[] CUT = { false, true, true };

    private static final String[] CONFIRM = {
        "ok", "oke", "matikan", "turn off", "nonaktifkan", "ya", "yes",
        "batasi", "restrict", "izinkan", "allow", "turn on", "aktifkan"
    };

    private Handler h;
    private Store st;
    private final ArrayDeque<String> queue = new ArrayDeque<String>();
    private boolean running = false;
    private boolean restore = false;
    private String cur;
    private int tick, entryTick, scrolls, lastAnyClick;
    private final int[] lastClick = new int[3];
    private final int[] attempts = new int[3];
    private long lastToast = 0;
    private String lastToastPkg = "";

    // ------------------------------------------------------------ lifecycle

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        inst = this;
        h = new Handler(Looper.getMainLooper());
        st = new Store(this);
        IntentFilter f = new IntentFilter(Intent.ACTION_USER_PRESENT);
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(rcv, f, Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(rcv, f);
            }
        } catch (Throwable t) { }
        st.addLog("Aksesibilitas nyuw aktif");
    }

    @Override
    public boolean onUnbind(Intent i) {
        inst = null;
        try { unregisterReceiver(rcv); } catch (Throwable t) { }
        return super.onUnbind(i);
    }

    @Override
    public void onInterrupt() { }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (running || e == null || st == null) return;
        if (e.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence cs = e.getPackageName();
        if (cs == null) return;
        String p = cs.toString();
        long now = System.currentTimeMillis();
        if (p.equals(lastToastPkg) && now - lastToast < 10 * 60 * 1000L) return;
        if (st.get("off").contains(p)) {
            lastToastPkg = p;
            lastToast = now;
            toast("nyuw: internet " + Apps.label(this, p)
                    + " sedang dimatikan. Buka nyuw > Pulihkan jika perlu.");
        }
    }

    // ------------------------------------------------------------ pemicu otomatis

    private final BroadcastReceiver rcv = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            if (h != null) {
                h.removeCallbacks(autoRun);
                h.postDelayed(autoRun, 4000);
            }
        }
    };

    private final Runnable autoRun = new Runnable() {
        public void run() {
            if (running || !st.auto()) return;
            long now = System.currentTimeMillis();
            if (now - st.lastRun() < 6 * 3600 * 1000L) return;
            if (!Apps.hasUsage(NyuwService.this)) return;
            List<String> l = Apps.inactive(NyuwService.this, st.days(), st.get("keep"), st.get("off"));
            st.setLastRun(now);
            if (l == null || l.isEmpty()) return;
            if (l.size() > 5) l = new ArrayList<String>(l.subList(0, 5));
            startRun(l, false);
        }
    };

    // ------------------------------------------------------------ antrian

    public boolean isRunning() { return running; }

    public boolean startRun(List<String> pkgs, boolean restoreMode) {
        if (running) return false;
        queue.clear();
        queue.addAll(pkgs);
        restore = restoreMode;
        running = true;
        toast("nyuw bekerja... jangan sentuh layar dulu");
        st.addLog((restoreMode ? "Pulihkan " : "Matikan ") + pkgs.size() + " aplikasi");
        h.postDelayed(new Runnable() { public void run() { next(); } }, 800);
        return true;
    }

    private void next() {
        cur = queue.poll();
        if (cur == null) {
            running = false;
            st.setLastRun(System.currentTimeMillis());
            toast("nyuw selesai. Lihat log di aplikasi.");
            return;
        }
        tick = 0;
        entryTick = 0;
        scrolls = 0;
        lastAnyClick = 0;
        Arrays.fill(lastClick, 0);
        Arrays.fill(attempts, 0);
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + cur));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
        } catch (Throwable t) {
            st.addLog("X gagal membuka pengaturan " + cur + ": " + t);
            cur = null;
            h.postDelayed(new Runnable() { public void run() { next(); } }, 500);
            return;
        }
        h.postDelayed(ticker, 1500);
    }

    private final Runnable ticker = new Runnable() {
        public void run() {
            try {
                step();
            } catch (Throwable t) {
                finishCurrent(0, "error " + t);
            }
        }
    };

    private void again() { h.postDelayed(ticker, 800); }

    // state 0 = gagal, 1 = sebagian, 2 = berhasil
    private void finishCurrent(int state, String msg) {
        String p = cur;
        cur = null;
        h.removeCallbacks(ticker);
        st.addLog((state == 2 ? "OK " : state == 1 ? "SEBAGIAN " : "GAGAL ")
                + Apps.label(this, p) + ": " + msg);
        if (state >= 1) {
            Set<String> off = st.get("off");
            if (restore) off.remove(p); else off.add(p);
            st.put("off", off);
        }
        performGlobalAction(GLOBAL_ACTION_BACK);
        h.postDelayed(new Runnable() {
            public void run() { performGlobalAction(GLOBAL_ACTION_BACK); }
        }, 500);
        h.postDelayed(new Runnable() { public void run() { next(); } }, 1400);
    }

    // ------------------------------------------------------------ satu langkah otomatisasi

    private void step() {
        if (!running || cur == null) return;
        tick++;
        if (tick > 40) { finishCurrent(0, "waktu habis (menu tidak ditemukan)"); return; }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) { again(); return; }
        List<AccessibilityNodeInfo> all = new ArrayList<AccessibilityNodeInfo>();
        walk(root, all, 0);

        // dialog konfirmasi setelah klik
        if (lastAnyClick > 0 && tick - lastAnyClick <= 2) {
            if (confirmDialog(all)) { again(); return; }
        }

        int found = 0, okc = 0;
        boolean pending = false;
        for (int s = 0; s < 3; s++) {
            boolean want = restore ? !CUT[s] : CUT[s];
            AccessibilityNodeInfo sw = null;
            for (AccessibilityNodeInfo n : all) {
                if (matches(n, KEYS[s])) {
                    AccessibilityNodeInfo x = switchFor(n);
                    if (x != null) { sw = x; break; }
                }
            }
            if (sw == null) continue;
            found++;
            if (sw.isChecked() == want) { okc++; continue; }
            if (lastClick[s] > 0 && tick - lastClick[s] < 3) { pending = true; continue; }
            if (attempts[s] >= 2) continue;
            if (clickNode(sw)) {
                attempts[s]++;
                lastClick[s] = tick;
                lastAnyClick = tick;
                pending = true;
            }
        }

        if (found > 0) {
            if (pending) { again(); return; }
            if (okc == found) finishCurrent(2, found + " pengaturan sesuai");
            else if (okc > 0) finishCurrent(1, okc + " dari " + found + " pengaturan sesuai");
            else finishCurrent(0, "tombol tidak bisa diubah");
            return;
        }

        // belum di halaman data: cari menunya
        if (entryTick == 0 || tick - entryTick >= 3) {
            for (AccessibilityNodeInfo n : all) {
                if (!n.isCheckable() && matches(n, ENTRY)) {
                    if (clickNode(n)) { entryTick = tick; again(); return; }
                }
            }
        }
        // tidak ketemu: gulir halaman
        if (scrolls < 8 && tick % 2 == 0) {
            for (AccessibilityNodeInfo n : all) {
                if (n.isScrollable() && n.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) {
                    scrolls++;
                    break;
                }
            }
        }
        again();
    }

    // ------------------------------------------------------------ util node

    private void walk(AccessibilityNodeInfo n, List<AccessibilityNodeInfo> out, int depth) {
        if (n == null || depth > 40 || out.size() > 2500) return;
        out.add(n);
        int c = n.getChildCount();
        for (int i = 0; i < c; i++) walk(n.getChild(i), out, depth + 1);
    }

    private String txt(AccessibilityNodeInfo n) {
        CharSequence a = n.getText();
        CharSequence b = n.getContentDescription();
        String s = (a == null ? "" : a.toString()) + " " + (b == null ? "" : b.toString());
        return s.toLowerCase(Locale.ROOT).trim();
    }

    private boolean matches(AccessibilityNodeInfo n, String[] keys) {
        String t = txt(n);
        if (t.length() == 0) return false;
        for (String k : keys) if (t.contains(k)) return true;
        return false;
    }

    private void collectCheckable(AccessibilityNodeInfo n, List<AccessibilityNodeInfo> out, int depth) {
        if (n == null || depth > 12) return;
        if (n.isCheckable()) out.add(n);
        int c = n.getChildCount();
        for (int i = 0; i < c; i++) collectCheckable(n.getChild(i), out, depth + 1);
    }

    /** Cari switch milik baris teks ini (harus tepat satu switch di barisnya). */
    private AccessibilityNodeInfo switchFor(AccessibilityNodeInfo n) {
        if (n.isCheckable()) return n;
        AccessibilityNodeInfo p = n;
        for (int i = 0; i < 3 && p != null; i++) {
            p = p.getParent();
            if (p == null) break;
            List<AccessibilityNodeInfo> c = new ArrayList<AccessibilityNodeInfo>();
            collectCheckable(p, c, 0);
            if (c.size() == 1) return c.get(0);
            if (c.size() > 1) return null;
        }
        return null;
    }

    private boolean clickNode(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo p = n;
        for (int i = 0; i < 4 && p != null; i++) {
            if (p.isClickable() && p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            p = p.getParent();
        }
        return false;
    }

    private boolean confirmDialog(List<AccessibilityNodeInfo> all) {
        for (AccessibilityNodeInfo n : all) {
            CharSequence cn = n.getClassName();
            if (cn == null || !cn.toString().contains("Button")) continue;
            String t = txt(n);
            for (String c : CONFIRM) {
                if (t.equals(c) && clickNode(n)) return true;
            }
        }
        return false;
    }

    private void toast(String s) {
        try { Toast.makeText(getApplicationContext(), s, Toast.LENGTH_LONG).show(); }
        catch (Throwable t) { }
    }
}
