package com.nyuw.hans;

import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Process;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Apps {

    public static boolean hasUsage(Context c) {
        try {
            AppOpsManager a = (AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
            int m = a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(), c.getPackageName());
            return m == AppOpsManager.MODE_ALLOWED;
        } catch (Throwable t) {
            return false;
        }
    }

    public static String label(Context c, String p) {
        try {
            PackageManager pm = c.getPackageManager();
            return pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString();
        } catch (Throwable t) {
            return p;
        }
    }

    /** Aplikasi pengguna (bukan sistem) yang tidak dibuka dalam [days] hari. */
    public static List<String> inactive(final Context c, int days, Set<String> keep, Set<String> off) {
        final List<String> out = new ArrayList<String>();
        if (!hasUsage(c)) return out;

        PackageManager pm = c.getPackageManager();
        long now = System.currentTimeMillis();
        long from = now - days * 86400000L;

        // 1. kumpulkan aplikasi yang dipakai dalam rentang waktu
        Set<String> used = new HashSet<String>();
        UsageStatsManager u = (UsageStatsManager) c.getSystemService(Context.USAGE_STATS_SERVICE);
        UsageEvents ev = u.queryEvents(from, now);
        UsageEvents.Event e = new UsageEvents.Event();
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e);
            int t = e.getEventType();
            if (t == UsageEvents.Event.MOVE_TO_FOREGROUND
                    || t == UsageEvents.Event.USER_INTERACTION) {
                used.add(e.getPackageName());
            }
        }

        // 2. daftar yang tidak boleh disentuh
        Set<String> skip = new HashSet<String>();
        skip.add(c.getPackageName());
        skip.addAll(keep);
        skip.addAll(off);
        try {
            InputMethodManager im = (InputMethodManager) c.getSystemService(Context.INPUT_METHOD_SERVICE);
            for (InputMethodInfo i : im.getEnabledInputMethodList()) skip.add(i.getPackageName());
        } catch (Throwable t) { }
        try {
            Intent hi = new Intent(Intent.ACTION_MAIN);
            hi.addCategory(Intent.CATEGORY_HOME);
            for (ResolveInfo r : pm.queryIntentActivities(hi, 0)) skip.add(r.activityInfo.packageName);
        } catch (Throwable t) { }

        // 3. saring
        for (ApplicationInfo ai : pm.getInstalledApplications(0)) {
            String p = ai.packageName;
            if ((ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
            if (skip.contains(p) || used.contains(p)) continue;
            if (pm.getLaunchIntentForPackage(p) == null) continue;
            try {
                if (pm.getPackageInfo(p, 0).firstInstallTime > from) continue;
            } catch (Throwable t) { continue; }
            out.add(p);
        }

        Collections.sort(out, new Comparator<String>() {
            public int compare(String a, String b) {
                return label(c, a).compareToIgnoreCase(label(c, b));
            }
        });
        return out;
    }
}
